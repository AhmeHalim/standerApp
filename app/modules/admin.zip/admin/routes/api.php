<?php

Route::get('/','ApiController@index');