<?php

Route::get('/','AdminController@index');
