<?php

namespace Admin\Models;

use Illuminate\Database\Eloquent\Model;

class Setting extends Model
{
   
}
