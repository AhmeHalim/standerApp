<?php

return [
//     'prefix'=>[
//         'admin'=>'dash-board',
//         'api'=>'api',
//     ],

    'module_name'=>'admin',

];